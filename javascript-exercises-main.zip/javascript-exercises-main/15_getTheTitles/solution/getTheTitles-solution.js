const getTheTitles = function (array) {
  return array.map((book) => book.title);
};

module.exports = getTheTitles;
