const getTheTitles = function() {

};

// Do not edit below this line
module.exports = getTheTitles;
