const a = 1 - 1 // Freebie!!! This is the answer to "one minus one"
const b = "one plus eight"
const c = "22 times three"
const d = "the *remainder* of 5/4"
const e = "the variable 'b' minus 17"
const f = "the sum of the previous five variables"

// Do not edit below this line
module.exports = {a, b, c, d, e, f}
