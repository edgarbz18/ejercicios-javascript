function addNumbers() {
	const a = 1;
	const b = 1;

	let result;

	result = a + b;

	return result;
}

module.exports = addNumbers;
